<link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/global.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/user-dashboard.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=681b9fe27c84420012f177e8&product=inline-share-buttons&source=platform" async="async"></script>