<div class="blog-sidebar">
                    <div class="sidebar-widget">
                        <h3 class="widget-title">Recent Blogs</h3>
                        
                        <div class="recent-blog">
                            <a href="blog-detail.html">
                                <img src="assets/upload/blog/blog-img1.jpg" alt="Recent Blog 1" class="recent-blog-img">
                                <div class="recent-blog-content">
                                    <h4 class="recent-blog-title">New advancements in laboratory safety protocols</h4>
                                    <div class="recent-blog-date">15-Dec-2024</div>
                                </div>
                            </a>
                        </div>
                        
                       
                    </div>
                </div>